Rails.application.routes.draw do
  devise_for :users

  # Main root route for the application
  root "posts#index"

  # Routes for posts
  resources :posts do
    resources :comments, only: [:create, :destroy]
    resources :likes, only: [:create, :destroy] do
      # Add a 'liked' route to check if the post is liked
      collection do
        get 'liked' # check if a post is liked
      end
    end
  end

  # Health check route
  get "up" => "rails/health#show", as: :rails_health_check
  
  # Route for deleting a post (outside of resources block)
  get '/posts/:id/delete', to: 'posts#destroy', as: :delete_post
end
