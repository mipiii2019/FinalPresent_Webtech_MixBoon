class Post < ApplicationRecord
  belongs_to :user
  has_many :likes, dependent: :destroy
  has_many :comments, dependent: :destroy

  # Method to check if a user has liked the post
  def liked_by?(user)
    likes.exists?(user_id: user.id)
  end
end
