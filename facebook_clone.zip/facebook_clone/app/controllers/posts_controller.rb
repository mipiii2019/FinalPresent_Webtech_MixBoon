class PostsController < ApplicationController
  before_action :authenticate_user!
  before_action :set_post, only: %i[edit update destroy]

  # แสดงโพสต์ทั้งหมด
  def index
    @posts = Post.paginate(page: params[:page], per_page: 10)
  end

  # สร้างโพสต์ใหม่
  def new
    @post = Post.new
  end

  # บันทึกโพสต์ใหม่
def create
  @post = current_user.posts.build(post_params)
  if @post.save
    respond_to do |format|
      format.html { redirect_to posts_path, notice: "Post created successfully." }
      format.json { render json: { notice: "Post created successfully." }, status: :created }
    end
  else
    respond_to do |format|
      format.html { render :new, alert: "Failed to create the post." }
      format.json { render json: { error: "Failed to create the post." }, status: :unprocessable_entity }
    end
  end
end


  # ฟอร์มแก้ไขโพสต์
  def edit; end

  # อัพเดตโพสต์
  def update
    if @post.update(post_params)
      redirect_to posts_path, notice: 'Post updated successfully.'
    else
      render :edit
    end
  end

  def show
    @post = Post.find_by(id: params[:id]) # ใช้ find_by เพื่อให้ไม่เกิดข้อผิดพลาดหากไม่พบโพสต์
    if @post.nil?
      redirect_to posts_path, alert: 'Post not found.' # หากไม่พบโพสต์ จะ redirect กลับไปที่หน้า posts
    end
  end
  


  def destroy
    @post = Post.find_by(id: params[:id])
  
    if @post.nil?
      redirect_to posts_path, alert: "Post not found."
    elsif @post.destroy
      redirect_to posts_path, notice: "Post was successfully deleted."
    else
      redirect_to posts_path, alert: "Failed to delete the post."
    end
  end
  

  

  private

  # ค้นหาโพสต์จาก id
  def set_post
    @post = Post.find(params[:id])
  end

  # กำหนด param ที่สามารถใช้ได้
  def post_params
    params.require(:post).permit(:title, :content)
  end
end
