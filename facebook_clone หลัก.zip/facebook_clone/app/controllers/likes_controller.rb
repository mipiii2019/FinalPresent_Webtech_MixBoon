# app/controllers/likes_controller.rb
class LikesController < ApplicationController
  before_action :authenticate_user!
  before_action :set_post

  def liked
    @liked = @post.likes.exists?(user_id: current_user.id)
    render json: { liked: @liked }
  end

  def create
    @like = @post.likes.create(user: current_user)

    respond_to do |format|
      format.js { render json: { likes_count: @post.likes.count } }
    end
  end

  def destroy
    @like = @post.likes.find_by(user: current_user)
    
    if @like
      @like.destroy
    end

    # ส่งจำนวน Likes กลับไปเป็น JSON สำหรับอัปเดต
    respond_to do |format|
      format.js { render json: { likes_count: @post.likes.count } }
    end
  end

  private

  def set_post
    @post = Post.find(params[:post_id])
  end
end
